﻿using Microsoft.Data.SqlClient;
using System.Data;
using System.Text;
using System.Windows;
namespace ContractMonthlyClaim;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private readonly string sqlConnection = "Data Source = LAPTOP-CONRE6DS\\SQLEXPRESS; Initial Catalog = CONTRACT_MONTHLY_CLAIM; Integrated Security = True; Trust Server Certificate = True";
    public string? userName;
    public string? password;
    public string? LecturerID;
    public MainWindow()
    {
        InitializeComponent();
        this.WindowState = WindowState.Maximized;
    }

    private void Submit_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            userName = txtUsername.Text.Trim();
            password = pbPassword.Password.Trim();
            int count = 0;

            using (SqlConnection connection = new SqlConnection(sqlConnection))
            {
                connection.Open();

                string query = "SELECT ClaimLecturer.Username, ClaimLecturer.[Password] FROM ClaimLecturer;";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        foreach (DataRow row in dataTable.Rows)
                        {
                            foreach (DataColumn column in dataTable.Columns)
                            {
                                if (userName.Equals(row[column]) || password.Equals(row[column]))
                                {
                                    count++;
                                }
                            }
                        }

                        if (count == 2)
                        {
                            setLecturerID();
                            Lecturer lecturer = new Lecturer(LecturerID!);
                            lecturer.WindowState = WindowState.Maximized;
                            lecturer.Show();
                            this.Close();
                            count = 0;
                        }
                    }
                }

                string secQuery = "SELECT ClaimProgrammeCoordinator.Username, ClaimProgrammeCoordinator.[Password] FROM ClaimProgrammeCoordinator;";

                using (SqlCommand secCommand = new SqlCommand(secQuery, connection))
                {
                    using (SqlDataReader reader = secCommand.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        foreach (DataRow row in dataTable.Rows)
                        {
                            foreach (DataColumn column in dataTable.Columns)
                            {
                                if (userName.Equals(row[column]) || password.Equals(row[column]))
                                {
                                    count++;
                                }
                            }
                        }

                        if (count == 2)
                        {
                            ProgrammeCoordinator coordinator = new ProgrammeCoordinator();
                            coordinator.WindowState = WindowState.Maximized;
                            coordinator.Show();
                            this.Close();
                            count = 0;
                        }
                    }
                }

                string thirdQuery = "SELECT ClaimAcademicManager.Username, ClaimAcademicManager.[Password] FROM ClaimAcademicManager;";

                using (SqlCommand thirdCommand = new SqlCommand(thirdQuery, connection))
                {
                    using (SqlDataReader reader = thirdCommand.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        foreach (DataRow row in dataTable.Rows)
                        {
                            foreach (DataColumn column in dataTable.Columns)
                            {
                                if (userName.Equals(row[column]) || password.Equals(row[column]))
                                {
                                    count++;
                                }
                            }
                        }

                        if (count == 2)
                        {
                            AcademicManager manager = new AcademicManager();
                            manager.WindowState = WindowState.Maximized;
                            manager.Show();
                            this.Close();
                            count = 0;
                        }
                    }
                }

                string fourthQuery = "SELECT ClaimHR.Username, ClaimHR.[Password] FROM ClaimHR;";

                using (SqlCommand fourthCommand = new SqlCommand(fourthQuery, connection))
                {
                    using (SqlDataReader reader = fourthCommand.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        foreach (DataRow row in dataTable.Rows)
                        {
                            foreach (DataColumn column in dataTable.Columns)
                            {
                                if (userName.Equals(row[column]) || password.Equals(row[column]))
                                {
                                    count++;
                                }
                            }
                        }

                        if (count == 2)
                        {
                            HR hr = new HR();
                            hr.WindowState = WindowState.Maximized;
                            hr.Show();
                            this.Close();
                            count = 0;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error while logging in: {ex.Message}", "Error Message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
        }
    }

    public void setLecturerID()
    {
        try 
        {
            using (SqlConnection connection = new SqlConnection(sqlConnection)) 
            {
                connection.Open();

                string query = "SELECT ClaimLecturer.LecturerID FROM ClaimLecturer WHERE Username = @Username AND [Password] = @Password;";

                using (SqlCommand command = new SqlCommand(query, connection)) 
                {
                    command.Parameters.AddWithValue("@Username", userName);
                    command.Parameters.AddWithValue ("@Password", password);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable table = new DataTable();
                        table.Load(reader);

                        foreach (DataRow row in table.Rows)
                        {
                            foreach (DataColumn column in table.Columns)
                            {
                                LecturerID = row[column].ToString();
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error getting the Lecturer ID: {ex.Message}", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
        }
    }
}