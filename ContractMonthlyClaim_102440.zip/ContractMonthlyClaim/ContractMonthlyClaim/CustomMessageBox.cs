﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContractMonthlyClaim
{
    public static class CustomMessageBox
    {
        public static void Show(string message, string title = "Message")
        {
            var box = new ScrollableMessageBox(message, title);
            box.ShowDialog();
        }
    }
}
