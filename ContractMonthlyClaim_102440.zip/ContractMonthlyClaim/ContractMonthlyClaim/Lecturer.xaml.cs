﻿using Microsoft.Win32;
using Microsoft.Data.SqlClient;
using System.Text;
using System.Windows;
using System.Data;
using System.IO;
using OfficeOpenXml;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Paragraph = DocumentFormat.OpenXml.Wordprocessing.Paragraph;
using System.Windows.Input;
using System.Text.RegularExpressions;

namespace ContractMonthlyClaim
{
    /// <summary>
    /// Interaction logic for Lecturer.xaml
    /// </summary>
    public partial class Lecturer : Window
    {
        private readonly string  sqlConnection = "Data Source=LAPTOP-CONRE6DS\\SQLEXPRESS;Initial Catalog=CONTRACT_MONTHLY_CLAIM;Integrated Security=True;Trust Server Certificate=True";
        private bool docUploaded = false;
        string filePath = "";
        private string lecturerID;

        public Lecturer(string id)
        {
            InitializeComponent();
            lecturerID = id;
        }

        private void Return_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.WindowState = WindowState.Maximized;
            window.Show();
            this.Close();
        }

        private void Upload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "PDF (*.pdf)|*.pdf|Word (*.docx)|*.docx|Excel (*.xlsx)|*.xlsx";
            if (openFileDialog.ShowDialog() == true)
            {
                filePath = openFileDialog.FileName;
                long fileSizeLimit = 10 * 1024 * 1024;
                try
                {
                    FileInfo fileInfo = new FileInfo(filePath);
                    if (fileInfo.Length < fileSizeLimit)
                    {
                        MessageBox.Show("Document uploaded", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                        fileNameTextBlock.Text = filePath;
                        docUploaded = true;
                    }
                    else
                    {
                        MessageBox.Show("File exceeds limit of 10MB.", "Error", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                        System.IO.File.Delete(filePath);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                }
            }
        }

        private void HoursWorked_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !Regex.IsMatch(e.Text, @"^[0-9]*(?:\.[0-9]*)?$");
        }

        private void HourlyRate_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !Regex.IsMatch(e.Text, @"^[0-9]*(?:\.[0-9]*)?$");
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtClaimID.Text) || docUploaded == false || string.IsNullOrEmpty(txtHours.Text) || string.IsNullOrEmpty(txtRate.Text) || !txtClaimID.Text.ToUpper().Contains("CL") || txtClaimID.Text.Length < 5)
            {
                MessageBox.Show("Please fill all requirements before submitting.", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }
            try
            {
                using (SqlConnection connection = new SqlConnection(sqlConnection))
                {
                    connection.Open();

                    string query = "INSERT INTO Claims(LecturerID, ClaimID, CoordinatorID, ManagerID, ClaimDoc, ClaimDate, ClaimAmount, Status) VALUES (@LecturerID, @ClaimID, @CoordinatorID, @ManagerID, @ClaimDoc, @ClaimDate, @ClaimAmount, @Status);";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@LecturerID", lecturerID);
                        command.Parameters.AddWithValue("@ClaimID", txtClaimID.Text.Trim().ToUpper());
                        command.Parameters.AddWithValue("@CoordinatorID", "CO001");
                        command.Parameters.AddWithValue("@ManagerID", "MA001");
                        command.Parameters.AddWithValue("@ClaimDate", $"{DateTime.Now.ToShortDateString()}");
                        command.Parameters.AddWithValue("@Status", "Pending");

                        double claimAmount = Convert.ToDouble(txtHours.Text.Trim()) * Convert.ToDouble(txtRate.Text.Trim());
                        command.Parameters.AddWithValue("@ClaimAmount", claimAmount);
                        
                        string fileExtension = System.IO.Path.GetExtension(filePath);
                        StringBuilder pdfText = new StringBuilder();
                        StringBuilder wordText = new StringBuilder();
                        StringBuilder excelText = new StringBuilder();
                        switch (fileExtension)
                        {
                            case ".pdf":
                                using (PdfReader reader = new PdfReader(filePath))
                                { 
                                    for (int page = 1; page <= reader.NumberOfPages; page++)
                                    {
                                        pdfText.AppendLine(PdfTextExtractor.GetTextFromPage(reader, page));
                                    }
                                }
                                command.Parameters.AddWithValue("@ClaimDoc", $"{txtClaimID.Text.Trim()}-{filePath} \n\n {pdfText.ToString()}");
                                break;
                            case ".doc": case ".docx":
                                using (WordprocessingDocument document = WordprocessingDocument.Open(filePath, true))
                                 {
                                    Body body = document.MainDocumentPart.Document.Body;
                                    foreach (Paragraph para in body.Elements<Paragraph>())
                                    {
                                        wordText.AppendLine(para.InnerText);
                                    }
                                 }
                                command.Parameters.AddWithValue("@ClaimDoc", $"{txtClaimID.Text.Trim()}-{filePath} \n\n {wordText.ToString()}");
                            break;

                            case ".xls": case ".xlsx":
                                using (ExcelPackage excel = new ExcelPackage(new FileInfo(filePath)))
                                {
                                    foreach (var worksheet in excel.Workbook.Worksheets)
                                    {
                                        ExcelWorksheet worksheet1 = excel.Workbook.Worksheets[worksheet.ToString()];
                                        for (int row = 1; row <= worksheet1.Dimension.End.Row; row ++)
                                        {
                                            for (int column = 1; column <= worksheet1.Dimension.End.Column; column ++)
                                            {
                                                excelText.AppendLine(worksheet1.Cells[row, column].Value?.ToString() + " ");
                                            }
                                            excelText.AppendLine(Environment.NewLine);
                                        }
                                    }
                                }
                                command.Parameters.AddWithValue("@ClaimDoc", $"{txtClaimID.Text.Trim()}-{filePath} \n\n {excelText.ToString()}");
                            break;

                            default:
                                MessageBox.Show("Unknown file type.", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                            break;
                        }

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Submitted successfully.", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        else
                        {
                            MessageBox.Show("Submission unsuccessful.", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                    ClearInputs();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error with submission: {ex.Message}", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                ClearInputs();
            }
        }

        private void View_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtLecturerID.Text.Trim())) 
            {
                MessageBox.Show("Please fill in your Lecturer ID", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }
            try
            {
                using (SqlConnection connection = new SqlConnection(sqlConnection))
                {
                    connection.Open();

                    string query = @"SELECT Claims.ClaimID, Claims.Status, Claims.ClaimAmount
                     FROM Claims
                     WHERE Claims.LecturerID = @LecturerID;";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@LecturerID", txtLecturerID.Text.Trim());

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            DataTable table = new DataTable();
                            table.Load(reader);

                            if (table.Rows.Count == 0)
                            {
                                MessageBox.Show("No data found.", "View", MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                            else
                            {
                                StringBuilder output = new StringBuilder();

                                foreach (DataRow row in table.Rows)
                                {
                                    foreach (DataColumn column in table.Columns)
                                    {
                                        output.AppendLine($"{column.ColumnName}: {row[column]}");
                                    }
                                    output.AppendLine("\n");
                                }
                                CustomMessageBox.Show(output.ToString(), "View");
                            }
                        }
                    }
                    ClearInputs();
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show($"Error when viewing claim status: {ex.Message}", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }
        }

        private void ClearInputs()
        {
            txtClaimID.Text = "";
            txtLecturerID.Text = "";
            txtHours.Text = "";
            txtRate.Text = "";
            fileNameTextBlock.Text = "For example, filename.txt";
        }
    }
}
