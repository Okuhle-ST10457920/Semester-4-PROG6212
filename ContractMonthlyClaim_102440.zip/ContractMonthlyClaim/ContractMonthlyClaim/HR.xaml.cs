﻿using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ContractMonthlyClaim
{
    /// <summary>
    /// Interaction logic for HR.xaml
    /// </summary>
    public partial class HR : Window
    {
        private readonly string sqlConnection = "Data Source=LAPTOP-CONRE6DS\\SQLEXPRESS;Initial Catalog=CONTRACT_MONTHLY_CLAIM;Integrated Security=True;Trust Server Certificate=True";
        public HR()
        {
            InitializeComponent();
        }

        private void Return_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.WindowState = WindowState.Maximized;
            window.Show();
            this.Close();
        }

        private void View_Claims_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(sqlConnection))
                {
                    connection.Open();

                    string query = "SELECT ClaimPayment.PaymentID, ClaimPayment.ClaimID, ClaimLecturer.Name, ClaimPayment.PaymentDate, ClaimPayment.PaymentAmount FROM Claims JOIN ClaimPayment ON Claims.ClaimID = ClaimPayment.ClaimID JOIN ClaimLecturer ON Claims.LecturerID = ClaimLecturer.LecturerID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            DataTable table = new DataTable();
                            table.Load(reader);

                            if (table.Rows.Count == 0)
                            {
                                MessageBox.Show("No data found.", "View", MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                            else
                            {
                                string? output = "";
                                foreach (DataRow row in table.Rows)
                                {
                                    foreach (DataColumn column in table.Columns)
                                    {
                                        output += $"{column.ColumnName}: {row[column]}\n";
                                    }
                                    output += "\n";
                                }
                                CustomMessageBox.Show(output, "View");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error when viewing claims: {ex.Message}", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void Manage_Lecturer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string lecturerID = Interaction.InputBox("Enter the lecturer ID:", "Manage Lecturer");

                if (string.IsNullOrWhiteSpace(lecturerID))
                {
                    MessageBox.Show("Lecturer ID cannot be empty.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                string option = Interaction.InputBox(
                    "Write down the option that you want to change. (Type it out as exactly as what it is written)\n\n" +
                    "1. Name\n2. Email\n3. ContactInfo",
                    "Manage Lecturer");

                if (string.IsNullOrWhiteSpace(option))
                {
                    MessageBox.Show("Option cannot be empty.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                string columnName = "";
                switch (option.Trim())
                {
                    case "1":
                    case "Name":
                        columnName = "Name";
                        break;
                    case "2":
                    case "Email":
                        columnName = "Email";
                        break;
                    case "3":
                    case "ContactInfo":
                        columnName = "ContactInfo";
                        break;
                    default:
                        MessageBox.Show("Invalid option selected.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                }

                string updateValue = Interaction.InputBox("Enter the new value:", "Manage Lecturer");

                if (string.IsNullOrWhiteSpace(updateValue))
                {
                    MessageBox.Show("Update value cannot be empty.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                using (SqlConnection connection = new SqlConnection(sqlConnection))
                {
                    connection.Open();

                    string query = $"UPDATE ClaimLecturer SET {columnName} = @UpdateValue WHERE LecturerID = @LecturerID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UpdateValue", updateValue);
                        command.Parameters.AddWithValue("@LecturerID", lecturerID);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data updated successfully", "Manage Claims", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        else
                        {
                            MessageBox.Show("No data updated.", "Manage Claims", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }
    }
}