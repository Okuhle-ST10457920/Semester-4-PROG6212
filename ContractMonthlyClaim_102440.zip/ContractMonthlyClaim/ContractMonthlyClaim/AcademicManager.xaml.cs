﻿using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic;
using System.Data;
using System.Windows;

namespace ContractMonthlyClaim
{
    /// <summary>
    /// Interaction logic for AcademicManager.xaml
    /// </summary>
    public partial class AcademicManager : Window
    {
        private readonly string sqlConnection = "Data Source=LAPTOP-CONRE6DS\\SQLEXPRESS;Initial Catalog=CONTRACT_MONTHLY_CLAIM;Integrated Security=True;Trust Server Certificate=True";
        public static bool processClaim;

        public AcademicManager()
        {
            InitializeComponent();
        }

        public void ProcessClaim()
        {
            processClaim = true;
        }

        private void Return_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.WindowState = WindowState.Maximized;
            window.Show();
            this.Close();
        }

        private void Review_Claims_Click(object sender, RoutedEventArgs e)
        {
            if (processClaim == true) 
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(sqlConnection))
                    {
                        connection.Open();

                        string query = "SELECT Claims.ClaimID, ClaimLecturer.Name, Claims.ClaimAmount, Claims.ClaimDate FROM ClaimLecturer INNER JOIN Claims ON ClaimLecturer.LecturerID = Claims.LecturerID GROUP BY Claims.ClaimID, ClaimLecturer.Name, Claims.ClaimAmount, Claims.ClaimDate;";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                DataTable table = new DataTable();
                                table.Load(reader);

                                if (table.Rows.Count == 0)
                                {
                                    MessageBox.Show("No data found.", "View", MessageBoxButton.OK, MessageBoxImage.Information);
                                }
                                else 
                                {
                                    string? output = "";
                                    foreach (DataRow row in table.Rows)
                                    {
                                        foreach (DataColumn column in table.Columns)
                                        {
                                            output += $"{column.ColumnName}: {row[column]}\n";
                                        }
                                        output += "\n";
                                    }
                                    CustomMessageBox.Show(output, "View");
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error when viewing claims: {ex.Message}", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                }
            }
            else
            {
                MessageBox.Show("Wait for the Programme Coordinator to process the claims.", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void Review_Docs_Click(object sender, RoutedEventArgs e)
        {
            if (processClaim == true)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(sqlConnection))
                    {
                        connection.Open();

                        string query = "SELECT Claims.ClaimDoc FROM Claims;";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                DataTable table = new DataTable();
                                table.Load(reader);

                                if (table.Rows.Count == 0)
                                {
                                    MessageBox.Show("No data found.", "View", MessageBoxButton.OK, MessageBoxImage.Information);
                                }
                                else
                                {
                                    string? output = "";
                                    foreach (DataRow row in table.Rows)
                                    {
                                        foreach (DataColumn column in table.Columns)
                                        {
                                            output += $"{row[column]}";
                                        }
                                        output += "\n";
                                    }
                                    CustomMessageBox.Show(output, "View");
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error when viewing document content: {ex.Message}", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                }
            }
            else
            {
                MessageBox.Show("Wait for the Programme Coordinator to process the claims.", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void Approve_Click(object sender, RoutedEventArgs e)
        {
            if (processClaim == true)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(sqlConnection))
                    {
                        connection.Open();

                        string claimID = Interaction.InputBox("Enter the claim ID you want to approve.", "Approve claim");

                        string query = "UPDATE Claims SET Status = 'Approved' WHERE Claims.ClaimID = @ClaimID;";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@ClaimID", claimID);

                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Data updated successfully", "Manage Claims", MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                            else
                            {
                                MessageBox.Show("No data found.", "Manage Claims", MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                        }

                        string secQuery = "INSERT INTO ClaimPayment(ClaimID, PaymentDate, PaymentAmount) VALUES (@ClaimID, @PaymentDate, @PaymentAmount);";

                        string thirdQuery = "SELECT Claims.ClaimAmount FROM Claims WHERE ClaimID = @ClaimID;";

                        using (SqlCommand secCommand = new SqlCommand(secQuery, connection))
                        {
                            secCommand.Parameters.AddWithValue("@ClaimID", claimID);
                            secCommand.Parameters.AddWithValue("@PaymentDate", $"{DateTime.Now.ToShortDateString()}");
                            using (SqlCommand thirdCommand = new SqlCommand(thirdQuery, connection))
                            {
                                thirdCommand.Parameters.AddWithValue("@ClaimID", claimID);

                                using (SqlDataReader reader = thirdCommand.ExecuteReader())
                                {
                                    DataTable table = new DataTable();
                                    table.Load(reader);
                                    foreach (DataRow row in table.Rows)
                                    {
                                        foreach (DataColumn column in table.Columns)
                                        {
                                            secCommand.Parameters.AddWithValue("@PaymentAmount", row[column]);
                                            break;
                                        }
                                    }
                                }
                            }
                            int rowsAffected = secCommand.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Claim and payment status updated successfully", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                            else
                            {
                                MessageBox.Show("Update unsuccessful", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                }
            }
            else
            {
                MessageBox.Show("Wait for the Programme Coordinator to process the claims.", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void Reject_Click(object sender, RoutedEventArgs e)
        {
            if (processClaim == true)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(sqlConnection))
                    {
                        connection.Open();

                        string claimID = Interaction.InputBox("Enter the claim ID you want to reject.", "Reject claim");

                        string query = "UPDATE Claims SET Status = 'Rejected' WHERE Claims.ClaimID = @ClaimID;";

                        using (SqlCommand sqlCommand = new SqlCommand(query, connection))
                        {
                            sqlCommand.Parameters.AddWithValue("@ClaimID", claimID);

                            int rowsAffected = sqlCommand.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Data updated successfully", "Manage Claims", MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                            else
                            {
                                MessageBox.Show("No data found.", "Manage Claims", MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                }
            }
            else
            {
                MessageBox.Show("Wait for the Programme Coordinator to process the claims.", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }
    }
}
